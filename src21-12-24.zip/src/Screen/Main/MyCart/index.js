import {
  Text,
  View,
  Image,
  Pressable,
  ScrollView,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {useIsFocused, useNavigation} from '@react-navigation/native';
import styles from './styles';
import {fontSize} from '../../../Component/fontsize';
import {colors} from '../../../Component/colors';
import {Rating} from 'react-native-ratings';
import {widthPrecent as wp} from '../../../Component/ResponsiveScreen/responsive';
import AsyncStorage from '@react-native-async-storage/async-storage';
const Remedies12SecondComponent = () => {
  const navigation = useNavigation();
  const [cartItemList, setCartItemList] = useState([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const handleNavigation = () => {
    navigation.navigate('RemediesInnerScreenFirst');
  };

  const focus = useIsFocused();

  useEffect(() => {
    getCartData();
    const checkLoginStatus = async () => {
      try {
        const userStatus = await AsyncStorage.getItem('user_data');
        const existingCart = await AsyncStorage.getItem('cartItems');

        // console.log('virendra',existingCart,userStatus);

        if (userStatus) {
          setIsLoggedIn(true);
        } else {
          setIsLoggedIn(false);
          // navigation.navigate('Login'); // Navigate to login screen if not logged in
        }
      } catch (error) {
        console.error('Error checking login status:', error);
      }
    };

    checkLoginStatus();
  }, [focus]);

  const getCartData = async () => {
    try {
      const cartData = await AsyncStorage.getItem('cartItems');
      const parsedCartData = cartData ? JSON.parse(cartData) : [];
      console.log('fjkgfg gfg dgsfg', cartData);

      setCartItemList(parsedCartData);

      console.log(cartItemList, 'Retrieved cart data');
    } catch (error) {
      console.error('Error retrieving cart data:', error);
    }
  };

  const increment = async id => {
    try {
      const updatedData = cartItemList.map(item =>
        item.id === id
          ? {
              ...item,
              quantity: item.quantity < 100 ? item.quantity + 1 : quantity,
            }
          : item,
      );
      setCartItemList(updatedData);
      await AsyncStorage.setItem('cartItems', JSON.stringify(updatedData));
    } catch (error) {
      console.log(error);
    }
  };

  const decrement = async id => {
    try {
      const updatedData = cartItemList.map(item =>
        item.id === id
          ? {
              ...item,
              quantity: item.quantity > 1 ? item.quantity - 1 : quantity,
            }
          : item,
      );

      setCartItemList(updatedData);
      await AsyncStorage.setItem('cartItems', JSON.stringify(updatedData));
    } catch (error) {
      console.log(error);
    }
  };

  const removerItem = async id => {
    try {
      const updatedData = cartItemList.filter(item => item.id !== id);
      setCartItemList(updatedData);

      await AsyncStorage.setItem('cartItems', JSON.stringify(updatedData));
    } catch (error) {
      console.log(error);
    }
  };

  const data2 = [
    {
      id: '1',
      source1: require('../../../assets/image/Remedies/ab.png'),
      title: 'Aluminium Metal Strip Vastu',
      price: '₹725.00',
      rating: 3,
      reviewCount: 2,
    },
    {
      id: '2',
      source1: require('../../../assets/image/Remedies/vk.png'),
      title: 'Copper Metal Strip',
      price: '₹725.00',
      rating: 3,
      reviewCount: 2,
    },
    {
      id: '3',
      source1: require('../../../assets/image/Remedies/dk.png'),
      title: 'Iron Metal Strip',
      price: '₹725.00',
      rating: 3,
      reviewCount: 2,
    },
    {
      id: '4',
      source1: require('../../../assets/image/Remedies/dk.png'),
      title: 'Brass Metal Strip',
      price: '₹725.00',
      rating: 3,
      reviewCount: 2,
    },
  ];

  const renderItem2 = ({item}) => (
    <View>
      <View style={styles.slide}>
        <TouchableOpacity onPress={() => navigation.navigate('ProductDetail')}>
          <Image source={item.source1} style={styles.image} />
        </TouchableOpacity>
        <View style={styles.textContainer}>
          <Text style={[styles.third, styles.titleText]}>{item.title}</Text>
          <Text style={[styles.third, {marginTop: 10}]}>{item.price}</Text>

          <View style={styles.direction}>
            <Rating
              type="custom"
              tintColor={colors.ordercolor}
              ratingCount={5}
              imageSize={wp(4)}
              startingValue={item.rating}
              ratingColor="#52B1E9"
              ratingBackgroundColor={colors.lightGrey} // Unfilled star color
            />
          </View>
          <TouchableOpacity style={styles.buttonstylefirst}>
            <Text style={styles.buttonstyle}>Add to Cart</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  const renderItem = ({item}) => (
    <View style={styles.viewinner}>
      <Image
        source={require('../../../assets/image/Remedies/ab.png')}
        style={styles.image1}
      />
      <View style={styles.contentContainer}>
        <Text style={styles.textstyle}>{item.name}</Text>
        <View style={styles.ruupebutton}>
          <View style={styles.rupees}>
            <Text style={styles.rupeestext}>₹ {item.price}</Text>
          </View>
          <View style={[styles.headerview, styles.quantitySection]}>
            <TouchableOpacity
              style={styles.touch}
              onPress={() => decrement(item.id)}>
              <Text style={[styles.third1, styles.quantityBtns]}>{'-'}</Text>
            </TouchableOpacity>
            <Text style={[styles.third1, {marginLeft: 5, marginTop: 3}]}>
              {item.quantity}
            </Text>
            <TouchableOpacity
              style={[styles.touch, {marginLeft: 0}]}
              onPress={() => increment(item.id)}>
              <Text style={[styles.third1, styles.quantityBtns]}>{'+'}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
      <TouchableOpacity
        style={styles.crossIcon}
        onPress={() => {
          removerItem(item.id);
        }}>
        <View style={styles.closeButton}>
          <Text style={styles.closeIcon}>+</Text>
        </View>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerview}>
          <TouchableOpacity onPress={() => navigation.openDrawer()}>
            <Image source={require('../../../assets/image/Drawer.png')} />
          </TouchableOpacity>
          <Image
            style={{marginLeft: 15}}
            source={require('../../../assets/image/header.png')}
          />
        </View>
        <TouchableOpacity
          onPress={() => navigation.navigate('Home', {screen: 'MyCart'})}
          style={styles.bagIcon}>
          <Image source={require('../../../assets/image/Group.png')} />
        </TouchableOpacity>
      </View>
      <View
        style={[
          styles.headerview,
          {
            elevation: 3,
            paddingVertical: 10,
            paddingHorizontal: 18,
            backgroundColor: '#fff',
          },
        ]}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Image
            style={styles.backBtn}
            source={require('../../../assets/drawer/Back1.png')}
          />
        </TouchableOpacity>

        <View style={styles.headerview}>
          <Text style={styles.logoText}>My Cart</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.scroll}>
        {isLoggedIn ? (
          <View style={styles.viewDeliver}>
            <View style={styles.toview}>
              <Text style={styles.textDeliver}>Deliver To:</Text>
              <Text style={styles.texttejash}>Tejash Shah, 400078</Text>
            </View>
            <View style={styles.loremview}>
              <Text style={styles.loremtext}>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. feugiat
                faucibus...{' '}
              </Text>
              <Text style={styles.change}>Change</Text>
            </View>
          </View>
        ) : null}

        {cartItemList?.length == 0 ? null : (
          // <Text style={[styles.viewinner1,styles.third,{textAlign:"center"}]}>Cart is Empty !</Text>
          <FlatList
            data={cartItemList}
            keyExtractor={item => item.id}
            renderItem={renderItem}
            contentContainerStyle={styles.viewinner1}
          />
        )}

        <View style={styles.main}>
          <Text style={styles.header1}>You May Also Like</Text>
          <FlatList
            data={data2}
            renderItem={renderItem2}
            horizontal
            keyExtractor={item => item.id}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{marginBottom: 15}}
          />
        </View>
      </ScrollView>
      <View style={styles.subtotalsavingyview}>
        <View style={styles.summaryview}>
          <Text style={styles.subtotaltext1}>Price Summary</Text>
        </View>

        <View style={styles.horizontalLine} />

        <View style={[styles.direction1, {marginBottom: -10}]}>
          <Text style={styles.subtotaltext}>SubTotal</Text>
          <View style={styles.rupees}>
            {/* <FontAwesome name="rupee" size={12} color="#324356" /> */}
            <Text style={styles.rupeestext}>₹ 1,855</Text>
          </View>
        </View>

        <View style={styles.direction1}>
          <Text style={[styles.subtotaltext, {paddingBottom: 10}]}>
            Saving :
          </Text>
          <View style={styles.rupees}>
            {/* <FontAwesome name="rupee" size={12} color="#324356" /> */}
            <Text style={styles.rupeestext}>₹ 0</Text>
          </View>
        </View>

        <View style={styles.horizontalLine} />

        <View style={styles.direction1}>
          <Text style={[styles.subtotaltext1, {paddingBottom: 5}]}>
            Grand Total :
          </Text>
          <View style={styles.rupees}>
            {/* <FontAwesome name="rupee" size={12} color="#324356" /> */}
            <Text style={styles.rupeestext}>₹ 1,855</Text>
          </View>
        </View>

        <TouchableOpacity
          onPress={() => {
            isLoggedIn
              ? navigation.navigate('AddressList')
              : navigation.navigate('Login');
          }}
          style={styles.book}>
          <Text style={styles.btext1}>PLACE ORDER</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default Remedies12SecondComponent;

const data = [
  {
    id: '1',
    title: 'Aluminium Metal Strip Vastu',
    price: '₹ 725.00',
    image: require('../../../assets/image/Remedies/ab.png'),
  },
  {
    id: '2',
    title: 'Aluminium Metal Strip Vastu',
    price: '₹ 725.00',
    image: require('../../../assets/image/Remedies/ab.png'),
  },
  // Add more items as needed
];
