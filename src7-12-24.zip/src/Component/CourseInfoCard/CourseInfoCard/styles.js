import {StyleSheet} from 'react-native';
import { colors } from '../../colors';
import { fontSize } from '../../fontsize';
import { widthPrecent as wp} from '../../ResponsiveScreen/responsive';

export default StyleSheet.create({
  section: {
    flexDirection: 'row',
    // alignItems:"center",
    borderWidth: 1,
    borderColor: '#DFE7EF',
    backgroundColor: '#FFFFFF',
    padding: 20,
    marginBottom: 10,
    borderRadius: 10,
    shadowColor: '#DFE7EF',
    shadowOffset: {width: 0, height: 3},
    shadowOpacity: 0.8,
    shadowRadius: 12,
    elevation: 12,
    marginTop:20,
    gap:5,
  },
  image: {
    marginTop: -20,
    height:wp(40),
    width: '55%',
    resizeMode: 'contain',
  },
  infoSection: {
    marginTop: wp(3),
    padding: 5,
    gap:5
  },
  TitleText: {
    color: colors.heading,
    fontSize: fontSize.Twenty,
    fontFamily:'Poppins-Medium',
    marginLeft:14
  },
  subHeadText: {
    color: colors.heading,
    fontSize: fontSize.Fourteen,
    fontFamily:'Poppins-Medium',
    marginLeft:14
  },
  regularText:{
    color: colors.heading,
    fontSize: fontSize.Twelve,
    fontFamily:'Poppins-Regular',
    marginLeft:14
  }
});
