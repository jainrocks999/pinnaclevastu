import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  FlatList,
  LayoutAnimation,
  Alert,
  ScrollView,
} from 'react-native';

import {useNavigation, DrawerActions} from '@react-navigation/native';

import {fontSize} from '../fontsize';
import {colors} from '../colors';
import styles from './styles';

const Drawer = props => {
  const navigation = useNavigation();
  const [loader, setLoader] = useState(false);
  const [visible, setVisibles] = useState(false);
  const [name, setName] = useState('');
  const manageDashboard = () => {
    // navigation.dispatch(DrawerActions.closeDrawer());
    navigation.navigate('Residental');
  };
  const manageDashboard1 = () => {
    // navigation.dispatch(DrawerActions.closeDrawer());
    navigation.navigate('Remedies');
  };
  const Loggout = () => {
    Alert.alert(
      'Are you sure you want to log out?',
      '',
      [
        {
          text: 'Cancel',
          onPress: () => {
            cancelable: false;
          },
          style: 'cancel',
        },
        {text: 'ok', onPress: () => Logout()},
      ],
      {cancelable: false},
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.topSection}>
        <Image source={require('../../assets/image/header.png')} />
        <TouchableOpacity onPress={() => props.navigation.closeDrawer()}>
          <Image source={require('../../assets/drawer/close.png')} />
        </TouchableOpacity>
      </View>

      <ScrollView>
        <View style={styles.listContainer}>
          <TouchableOpacity
            onPress={() => manageDashboard()}
            style={styles.listRow}>
            <Image
              style={styles.icon}
              source={require('../../assets/drawer/house.png')}
            />
            <Text style={styles.listText}>Residential Vastu</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.listRow}>
            <Image
              style={styles.icon}
              source={require('../../assets/drawer/office.png')}
            />
            <Text style={styles.listText}>Commercial Vastu</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.listRow}>
            <Image
              style={styles.icon}
              source={require('../../assets/drawer/industry.png')}
            />
            <Text style={styles.listText}>Industrial Vastu</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.listRow}>
            <Image
              style={styles.icon}
              source={require('../../assets/drawer/numerology.png')}
            />
            <Text style={styles.listText}>Numerology</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.listRow}>
            <Image
              style={styles.icon}
              source={require('../../assets/drawer/Layer.png')}
            />
            <Text style={styles.listText}>Gemstone</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.listRow}>
            <Image
              style={styles.icon}
              source={require('../../assets/drawer/beads.png')}
            />
            <Text style={styles.listText}>Rudrakasha</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.specialListRow}>
            <View
              style={{
                flexDirection: 'row',
              }}>
              <Image
                style={styles.icon}
                source={require('../../assets/drawer/app.png')}
              />
              <Text style={styles.listText}>More</Text>
            </View>
            <Image source={require('../../assets/drawer/right.png')} />
          </TouchableOpacity>
        </View>
        <TouchableOpacity style={styles.coursesListRow}>
          <View
            style={{
              flexDirection: 'row',
            }}>
            <Image
              style={styles.icon}
              source={require('../../assets/drawer/Icon.png')}
            />
            <Text style={[styles.listText, {color: colors.white}]}>
              Courses
            </Text>
          </View>
          <Image source={require('../../assets/drawer/right.png')} />
        </TouchableOpacity>
      </ScrollView>

      <View style={styles.sections}>
        <TouchableOpacity style={styles.extraListItem}>
          <Text style={[styles.extraListText, {color: colors.orange}]}>
            Numerology Calculator
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.extraListItem}>
          <Text style={[styles.extraListText, {color: colors.drawertitle}]}>
            Lucky Gemstone!
          </Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.extraListItem}>
          <Text style={[styles.extraListText, {color: '#1F5822'}]}>
            Astro Kundli Insights!
          </Text>
        </TouchableOpacity>
      </View>

      <View style={styles.sections}>
        <View style={styles.socialLinksContainer}>
          <Text style={styles.headText}>Follow us On</Text>
          <Text style={styles.versionText}>Version 1.05.11</Text>
        </View>
        <View style={styles.socialIconContainer}>
          <Image source={require('../../assets/drawer/fb.png')} />
          <Image
            style={{marginLeft: 5}}
            source={require('../../assets/drawer/instagram.png')}
          />
          <Image
            style={{marginLeft: 5}}
            source={require('../../assets/drawer/youtube.png')}
          />
        </View>
      </View>

      {/* <View
        style={{
          bottom: 100,
          left: 0,
          right: 0,
          position: 'absolute',
          paddingLeft: 20,
          width:'100%',
          borderWidth:0.1,
          paddingHorizontal:20
         
        }}>
          <View style={{flexDirection:'row',justifyContent:'space-between',width:'100%'}}>
           <Text
          style={{
            fontSize: fontSize.Fifteen,
            fontFamily: 'Poppins-Regular',
            color:colors.heading,
           
          }}>
         Follow us On
        </Text>
        <Text
          style={{
            fontSize: fontSize.Fifteen,
            fontFamily: 'Poppins-Regular',
            color:colors.Headertext,
            // textDecorationLine:'underline'
          }}>
         Version 1.05.11
        </Text>
        </View>
      </View> */}
    </View>
  );
};

export default Drawer;
