import {StyleSheet} from 'react-native';
import { widthPrecent } from '../../ResponsiveScreen/responsive';
import { colors } from '../../colors';
import { fontSize } from '../../fontsize';

export default StyleSheet.create({
  card: {
    width: widthPrecent(43),
    backgroundColor: '#FBF5F2',
    borderRadius:10
  },
  cardImg: {
    width: '100%',
    height:widthPrecent(55),
    resizeMode: 'contain',
    marginTop: -widthPrecent(12),
  },
  cardInfo: {
    marginTop: -30,
    padding: 10,
    gap:6
  },
  DateText: {
    color: colors.Headertext,
    fontSize: fontSize.Twelve,
    fontFamily:'Poppins-Medium'
  },
  titleText: {
    fontSize: fontSize.Fourteen,
    color: colors.heading,
    fontFamily:'Poppins-SemiBold',
  },
  regularText: {
    color: '#51575C',
    fontSize: fontSize.Fourteen,
    fontFamily:'Poppins-Regular',
    width:"90%"
  },
  price: {
    fontSize:fontSize.Fourteen,
    color: colors.heading,
    fontFamily:'Poppins-Bold',
  },
  cardBtn: {
    marginVertical:5,
    color:colors.white,
    fontSize:fontSize.Twelve,
    fontFamily:'Poppins-Medium',
    backgroundColor: colors.orange,
    padding: 10,
    width: 105,
    textAlign: 'center',
    borderRadius: 6,
  },
});
