import {View, Text, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import styles from './styles';
import { useNavigation } from '@react-navigation/native';

const LiveCourseCard = ({}) => {
  const navigation =useNavigation()
  return (
    <View style={styles.card}>
      <Image source={require('../../../assets/otherApp/courseCard1.png')} 
      style={styles.cardImg}/>
      <View style={styles.cardInfo}>
        <Text style={styles.DateText}>20 Nov 2024</Text>
        <Text style={styles.titleText}>ADVANCE VASTU COURSE</Text>
        <Text style={styles.regularText}>While Vastu Shastra gives us data about our...</Text>
        <Text style={styles.price}>₹ 7250.00</Text>
        <TouchableOpacity onPress={()=>navigation.navigate('CourseDetail')}>
          <Text style={styles.cardBtn}>View Details</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default LiveCourseCard;
