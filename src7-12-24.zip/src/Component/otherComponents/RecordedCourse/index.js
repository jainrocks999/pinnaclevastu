import {View, Text, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import styles from './styles';

const RecordedCourseCard = () => {
  return (
    <View style={styles.card}>
      <Image source={require('../../../assets/otherApp/courseCard2.png')} 
      style={styles.cardImg}/>
      <View style={styles.cardInfo}>
        <Text style={styles.DateText}>20 Nov 2024</Text>
        <Text style={styles.titleText}>ADVANCE VASTU COURSE</Text>
        <Text style={styles.regularText}>While Vastu Shastra gives us data about our...</Text>
        <Text style={styles.price}>₹ 7250.00</Text>
        <TouchableOpacity>
          <Text style={styles.cardBtn}>View Details</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default RecordedCourseCard;
