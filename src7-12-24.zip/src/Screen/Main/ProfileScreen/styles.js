import {StyleSheet} from 'react-native';
import {fontSize} from '../../../Component/fontsize';
import {colors} from '../../../Component/colors';
import {
  widthPrecent as wp,
  heightPercent as hp,
} from '../../../Component/ResponsiveScreen/responsive';

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    // paddingTop: 50,
  },
  header: {
    flexDirection: 'row',
    // justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 15,
    paddingVertical: 10,
    backgroundColor: '#fff',

    elevation: 5,
  },
  headerview: {
    //    marginLeft:wp(3)
  },
  logoText: {
    fontSize: fontSize.Eighteen,

    color: colors.heading,
    fontFamily: 'Poppins-Regular',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 15,
    marginVertical: 15,
    backgroundColor: '#fff',
    borderRadius: 10,
    elevation: 3,
    paddingHorizontal: 15,
  },

  profileCard: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    gap: wp(3),
  },

  cardImage: {
    height: wp(30),
    width: wp(28),
  },

  direction: {
    paddingVertical: 10,
  },

  searchInput: {
    flex: 1,
    fontSize: 16,
    paddingHorizontal: 15,
    color: '#555',
    paddingVertical: 10,
  },
  image: {
    height: wp(6),
    width: wp(6),
  },
  main: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 15,
    backgroundColor: colors.Resident,
    paddingVertical: 10,
  },
  title: {
    fontSize: fontSize.Fourteen,
    fontFamily: 'Poppins-Regular',
    color: colors.cardcolor,
  },
  servicesContainer: {
    paddingBottom: 30,

    paddingHorizontal: 10,
  },
  listContainer: {
    //  margin:10
    // paddingHorizontal:5,
    // paddingTop: hp(2),
  },

  cardContainer2: {
    alignSelf: 'center',
    width: '95%',
    paddingVertical: 10,
    marginTop: 10,
    backgroundColor: colors.white,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#DFE7EF',
    shadowColor: '#D8E3E9',
    shadowOffset: {width: 0, height: 6},
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 6, // For Android shadow effect
    paddingHorizontal: 5,
    // margin:5,

    justifyContent: 'center',
    // marginVertical: 10,
  },
  card: {
    width: '50%',
  },
  third: {
    fontSize: fontSize.Fifteen,
    color: colors.orange,
    fontFamily: 'Poppins-Medium',
  },
  third1: {
    fontSize: fontSize.Eighteen,
    color: colors.heading,
    fontFamily: 'Poppins-Medium',
  },
  third2: {
    fontSize: fontSize.Fourteen,
    color: '#51575C',
    fontFamily: 'Poppins-Regular',
  },
  cardContainer: {
    height: wp(28),
    width: wp(28),
    margin: 5,
    backgroundColor: colors.white,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 3, // Shadow for Android
    shadowColor: '#000', // Shadow for iOS
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.2,
    shadowRadius: 5,
    padding: 5,
  },

  text: {
    marginTop: hp(1),
    fontSize: fontSize.Fifteen,
    fontFamily: 'Poppins-Regular',
    color: colors.heading,
    textAlign: 'center',
  },
  contain: {
    marginLeft: 10,
    marginTop: hp(2),
  },
  service: {
    fontSize: fontSize.Twenty,
    color: colors.heading,
    fontFamily: 'Poppins-Medium',
  },
  cont: {
    fontSize: fontSize.Fourteen,
    color: colors.cardcolor,
    fontFamily: 'Poppins-Regular',
    opacity: 1,
    marginTop: hp(2),
    // textAlign:'center'
  },
  shareview: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 5,
    marginTop: hp(3),
    alignItems: 'center',
  },
  button: {
    paddingVertical: wp(1.5),
    alignItems: 'center',
    backgroundColor: colors.orange,
    width: '35%',
    borderRadius: 5,
  },
  btext: {
    fontFamily: 'Poppins-Regular',
    fontSize: fontSize.Fourteen,
    color: colors.white,
  },
  socialImg: {
    height: wp(4.5),
    width: wp(4.5),
    marginLeft: 8,
  },
  seeall: {
    fontSize: fontSize.Fifteen,
    fontFamily: 'Poppins-Regular',
    color: colors.orange,
    marginVertical: hp(2),
    marginRight: 20,
    textAlign: 'right',
  },
  book: {
    backgroundColor: colors.orange,
    alignItems: 'center',
    height: wp(12),
    width: '100%',
    borderRadius: 10,
    justifyContent:"center",
    marginTop: hp(2),
  },
  btext1: {
    fontFamily: 'Poppins-Medium',
    fontSize: fontSize.Eighteen,
    color: colors.white,
  },
  reviewSection: {
    marginTop: 20,
    backgroundColor: '#F1F1F1',
  },
  reviewCard: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    // alignItems: 'center',
    gap: 10,
    padding: 10,
  },
  reviewImage: {
    width: wp(15), // Set the width of the images
    height: wp(15), // Set the height of the images
    borderRadius: 10, // Optional: border radius for rounded corners
  },
  shareIcon: {
    borderRadius: 50,
    width: wp(6),
    height: wp(6),
  },
  rowSection: {
    flexDirection: 'row',
    gap: 5,
    alignItems: 'center',
  },
  backBtn: {
    height: wp(4),
    width: wp(2.3),
    resizeMode: 'stretch',
    marginRight:20
  },
});
