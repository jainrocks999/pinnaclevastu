import React, {useState} from 'react';
import {
  View,
  Text,
  TextInput,
  Image,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  FlatList,
  ImageBackground,
} from 'react-native';
import styles from './styles';
import {colors} from '../../../Component/colors';
import BannerSlider from '../../../Component/Banner';
import ButtomTab from '../../../Component/ButtomTab';
import {Rating} from 'react-native-ratings';
import {widthPrecent as wp} from '../../../Component/ResponsiveScreen/responsive';
const ResidentalScreen = ({navigation}) => {
  const data2 = [
    {
      id: '1',
      image: require('../../../assets/image/house.png'),
      name: 'Residential Vastu',
    },
    {
      id: '3',
      image: require('../../../assets/image/industry.png'),
      name: 'Industrial Vastu',
    },
    {
      id: '5',
      image: require('../../../assets/image/Layer_x.png'),
      name: 'Gemstone',
    },
  ];

  const renderItem = ({item}) => {
    let backgroundColor;

    // Check item name and set background color
    if (item.name === 'Residential Vastu') {
      backgroundColor = colors.card4;
    } else if (item.name === 'Industrial Vastu') {
      backgroundColor = colors.card5;
    } else if (item.name === 'Gemstone') {
      backgroundColor = colors.card2; // Add this for 'Industrial Vastu'
    } else {
      backgroundColor = colors.card3; // Default color for any other items
    }

    return (
      <TouchableOpacity style={[styles.cardContainer, {backgroundColor}]}>
        <Image source={item.image} style={styles.image} />
        <Text style={styles.text}>{item.name}</Text>
      </TouchableOpacity>
    );
  };
  const renderItem3 = ({item}) => {
    return (
      <TouchableOpacity
        onPress={() => navigation.navigate('profile')}
        style={[styles.cardContainer2]}>
        <View style={styles.reviewCard}>
          <View style={{gap: 10}}>
            <Image style={styles.reviewImage} source={item.image} />

            <Rating
              type="custom"
              tintColor={colors.white}
              ratingCount={5}
              imageSize={wp(4)}
              startingValue={item.rating}
              ratingColor="#52B1E9"
              ratingBackgroundColor={colors.lightGrey} // Unfilled star color
            />
          </View>
          <View style={[styles.card, {width: '65%'}]}>
            <Text style={styles.third1}>{item.name}</Text>

            <Text style={styles.third2}>{item.msg}</Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };
  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
      <TouchableOpacity
            onPress={() => navigation.goBack()}>
            <Image
              style={styles.backBtn}
              source={require('../../../assets/drawer/Back1.png')}
            />
          </TouchableOpacity>

        <View style={styles.headerview}>
          <Text style={styles.logoText}>Profile</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.servicesContainer}>
        <View style={styles.listContainer}>
          <View style={[styles.cardContainer2]}>
            <View style={styles.profileCard}>
              <View>
                <Image
                  style={styles.cardImage}
                  source={require('../../../assets/image/Rectangle.png')}
                />

                <View style={styles.direction}>
                  <Rating
                    type="custom"
                    tintColor={colors.white}
                    ratingCount={5}
                    imageSize={wp(3.8)}
                    startingValue={2}
                    ratingColor="#52B1E9"
                    ratingBackgroundColor={colors.lightGrey} // Unfilled star color
                  />
                </View>
              </View>
              <View style={styles.card}>
                <Text style={styles.third1}>{'Shreni Rajbhandary'}</Text>

                <Text style={styles.third2}>
                  {'Residential Vastu, Industrial Vastu, Gemstone'}
                </Text>
                <Text style={[styles.third2]}>{'Marathi, Hindi, English'}</Text>
                <Text style={[styles.third2]}>{'6 Years'}</Text>
                <Text style={[styles.third2]}>{'₹ 500 to ₹ 25000'}</Text>
              </View>
            </View>
          </View>
        </View>

        <View style={styles.contain}>
          <Text style={styles.service}>Specialist</Text>
        </View>
        <FlatList
          data={data2}
          renderItem={renderItem}
          keyExtractor={item => item.id}
          numColumns={3}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{
            alignSelf: 'center',
            gap: 15,
            paddingHorizontal: 0,
          }}
        />
        <View style={{paddingHorizontal: 10}}>
          <Text style={styles.cont}>
            {
              "“Many people say that an individual’s positive energy lights up the room, but I think it's the people around us who give us the strength.” Shreni Rajbhandary is a young and aspiring Vastu Consultant, Numerologist and Gemologist. Apart from this, she is a development practitioner who is currently working at the Ministry of Home Affairs (NDRRMA) in the Project Implementation Unit under the World Bank’s EHRP-P155969. She has been professionally involved in the environment and urban planning sector since 2017. While doing so, she was curious about spaces and how traditionally, spaces were developed in this part of the world. With this curiosity, she started to uncover more about Vastu Shastra. She is not just developing Vastu-compliant properties but is also involved in Vastu-compliant urban spaces. Her clients are primarily from the government, development, diplomatic, and business sectors. She has also been consulting students and young professionals to seek the best possible solutions per numerology. Pinnacle Vastu is gratified to share light and knowledge with and through Shreni Rajbhandary."
            }
          </Text>
        </View>
        <View style={styles.shareview}>
          <View style={styles.rowSection}>
            <Image 
            style={styles.shareIcon}
            source={require('../../../assets/otherApp/share.png')} />

            <Text style={[styles.cont, {marginTop: 0}]}>{'Share it :'}</Text>
            <Image
              style={styles.socialImg}
              source={require('../../..//assets/drawer/fb.png')}
            />
            <Image
              style={styles.socialImg}
              source={require('../../../assets/drawer/instagram.png')}
            />
            <Image
              style={styles.socialImg}
              source={require('../../../assets/drawer/copy.png')}
            />
          </View>
          <TouchableOpacity style={styles.button}>
            <Text style={styles.btext}>Write a Review</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.reviewSection}>
          <View style={styles.contain}>
            <Text style={styles.service}>User Reviews (22)</Text>
          </View>
          <FlatList
            data={data1}
            renderItem={renderItem3}
            keyExtractor={item => item.id}
            //   numColumns={3}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{paddingHorizontal: 0}}
          />

          <Text style={styles.seeall}>See all Reviews</Text>
        </View>
        <TouchableOpacity
          onPress={() => navigation.navigate('Appoiment')}
          style={styles.book}>
          <Text style={styles.btext1}>BOOK NOW</Text>
        </TouchableOpacity>
      </ScrollView>
      {/* <ButtomTab /> */}
    </View>
  );
};

export default ResidentalScreen;

const data1 = [
  {
    id: '1',
    image: require('../../../assets/image/Ellipse1.png'),
    name: 'Vikash',
    msg: 'Thanku so much madam ji ',
  },
  {
    id: '3',
    image: require('../../../assets/image/Ellipse2.png'),
    name: 'Sudhir',
    msg: 'Thanku so much madam ',
  },
  {
    id: '5',
    image: require('../../../assets/image/Ellipse3.png'),
    name: 'Hemant',
    msg: 'VeryNice',
  },
];
