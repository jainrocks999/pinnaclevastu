import {StyleSheet} from 'react-native';
import { fontSize } from '../../../Component/fontsize';
import { colors } from '../../../Component/colors';
import { widthPrecent as wp } from '../../../Component/ResponsiveScreen/responsive';

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 15,
    paddingVertical:10,
    backgroundColor: '#FBF5F2',
    borderBottomWidth: 0.5,
    borderColor: '#DFE7EF',
    gap: 10,
  },
  backIcon: {
    width: 14,
    height: 14,
    color: '#324356',
  },
  headerView:{
    flexDirection: 'row', 
    alignItems: 'center',
    // marginTop:5,
  },
  headerTitle: {
    fontSize: fontSize.Sixteen,
    fontFamily:'Poppins-Regular',
    color:colors.heading,
  },
  imageSection: {
    backgroundColor: '#FBF5F2',
    width: '100%',
    height: 150,
    borderBottomStartRadius: 30,
    borderBottomEndRadius: 30,
  },
  mainImg: {
    height: wp(25),
    width: wp(25),
    // resizeMode: 'contain',
    borderRadius: 80,
    margin: 'auto',
    borderWidth: 1,
    borderColor: '#D8E3E980',
    shadowColor: '#00000029',
    shadowOffset: {width: 0, height: 3},
    shadowOpacity: 0.8,
    shadowRadius: 12,
    elevation: 12,
    marginBottom: -wp(13),
    zIndex: 1,
  },
  ProfileInfoSection: {
    overflow: 'hidden',
    backgroundColor: '#F5FAFF',
    borderWidth: 1,
    borderColor: '#D8E3E980',
    shadowColor: '#00000029',
    shadowOffset: {width: 0, height: 3},
    shadowOpacity: 0.8,
    shadowRadius: 12,
    elevation: 12,
    borderBottomStartRadius: 30,
    borderBottomEndRadius: 30,
  },
  InfoSection: {
    backgroundColor: '#F5FAFF',
    padding: 15,
    width: '100%',
    // height: 250,
    paddingTop:wp(16),
    justifyContent: 'flex-end',
    alignItems: 'center',
    gap: 5,
  },
  nameText: {
    marginBottom: 5,
    color:colors.heading,
    lineHeight: wp(6),
    textAlign: 'center',
    fontSize: fontSize.Seventeen,
    fontFamily:'Poppins-Medium',
    width: wp(50),
  },
  dateInfoContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 5,
  },
  sectionText: {
    fontSize: fontSize.Twelve,
    fontFamily:'Poppins-Medium',
    color:colors.heading,
  },
  dateText: {
    fontSize: fontSize.Twelve,
    fontFamily:'Poppins-SemiBold',
  },
  ImgIcon: {
    height: wp(4),
    width: wp(4),
  },
  textContainer: {
    paddingVertical: 10,
    paddingHorizontal: 20,
  },
  cardStar:{
    flexDirection:'row',
    justifyContent:"center",
    alignItems:"center",
    gap:5
  },
  ratingText:{
  fontSize:fontSize.Twelve,
  color:"#949494"
  },
  smallText: {
    fontSize:fontSize.Fourteen,
    color: colors.paymenttext,
    fontFamily:'Poppins-Regular',
    lineHeight: wp(4.5),
  },
  reviewForm: {
    backgroundColor: '#F1F1F1',
    paddingVertical: 20,
    paddingHorizontal: 30,
    gap: 10,
    borderRadius:10,
    marginTop:10
  },
  formHeadText: {
    fontSize: fontSize.Eighteen,
    fontFamily:'Poppins-Medium',
    textAlign: 'center',
    color:colors.heading,
  },
  textInputContainer: {
    backgroundColor:colors.white,
    paddingHorizontal: 15,
   paddingVertical:7,
    borderRadius: 10,
    borderWidth: 0.5,
    borderColor: '#E9E9E9',
  },
  lableText: {
   fontSize:fontSize.Fourteen,
   fontFamily:'Poppins-Medium',
   color:colors.heading,marginLeft:5
  },
  textInput: {
    // borderWidth: 1,
    fontSize: fontSize.Fourteen,
  },
  starContainer: {
    marginVertical: 5,
    alignSelf:"flex-start",
    borderWidth:0.1
  },
  submitBtn: {
    color:colors.white,
    fontSize:fontSize.Sixteen,
    fontFamily:'Poppins-Regular',
    backgroundColor:colors.orange,
    textAlign: 'center',
    textAlignVertical:"center",
    // padding:16,
    borderRadius:10,
    shadowColor: '#E5C8C1',
    shadowOffset: {width: 0, height: 3},
    shadowOpacity: 0.8,
    shadowRadius: 12,
    elevation: 12,
    marginVertical:10,
    height: wp(12),
  },
  heightInput:{
    height:120
  },
  backBtn: {
    height: wp(4),
    width: wp(2.3),
    resizeMode: 'stretch',
    marginRight:20
  },
});
