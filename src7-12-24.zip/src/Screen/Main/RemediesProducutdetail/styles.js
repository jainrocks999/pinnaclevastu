import {StyleSheet} from 'react-native';
import {fontSize} from '../../../Component/fontsize';
import {colors} from '../../../Component/colors';
import {
  widthPrecent as wp,
  heightPercent as hp,
} from '../../../Component/ResponsiveScreen/responsive';

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    // paddingTop: 50,
  },

  titleText: {
    minHeight: wp(10),
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 15,
    paddingVertical: 10,
    backgroundColor: '#fff',
    elevation: 5,
  },
  headerview: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logoText: {
    fontSize: fontSize.Eighteen,
    color: colors.heading,
    fontFamily: 'Poppins-Regular',
  },
  welcomeCard: {},
  shareIcon: {
    resizeMode: 'contain',
    height: wp(6),
    width: wp(12),
    borderRadius: wp(20),
    backgroundColor: colors.ordercolor,
  },
  main: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '99%',
    marginTop:8,
    paddingBottom:10,
    borderColor: '#949494',
    borderBottomWidth: 0.5,
  },
  suggestItemContainer: {},
  title: {
    fontSize: fontSize.Fourteen,
    fontFamily: 'Poppins-Regular',
    color: colors.cardcolor,
  },
  reviewUser: {
    height: wp(18),
    width: wp(18),
    alignSelf: 'center',
  },
  servicesContainer: {
    marginBottom: 30,
    paddingHorizontal: 10,
  },
  listContainer: {
    backgroundColor: colors.cardm,
    margin: 8,
    gap: 10,
    borderRadius: 10,
    overflow: 'hidden',
  },
  cardContainer: {
    // margin: 5,
    width:wp(30),
    backgroundColor: colors.cardm,
    alignItems: 'center',
    gap:5,
    // justifyContent: 'center',
    // elevation: 3, // Shadow for Android
    shadowColor: '#000', // Shadow for iOS
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.2,
    shadowRadius: 5,
    padding: 5,
    paddingVertical: 25,
  },
  text: {
    // marginTop: hp(1),
    width:"90%",
    fontSize: fontSize.Fourteen,
    fontFamily: 'Poppins-Regular',
    color: colors.heading,
    textAlign: 'center',
  },
  cardContainer2: {
    width: '95%',
    marginHorizontal: 'auto',
    // paddingVertical: 5,
    marginTop: 10,
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#DFE7EF',
    shadowColor: '#D8E3E9',
    shadowOffset: {width: 0, height: 6},
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 6, // For Android shadow effect
    paddingHorizontal: 5,
    // margin:5,

    justifyContent: 'center',
    // marginVertical: 10,
  },
  card: {
    width: '50%',
  },
  third: {
    fontSize: fontSize.Fifteen,
    color: colors.orange,
    fontFamily: 'Poppins-Medium',
  },
  third1: {
    fontSize: fontSize.Eighteen,
    color: colors.heading,
    fontFamily: 'Poppins-Medium',
  },
  third2: {
    fontSize: fontSize.Fourteen,
    color: '#51575C',
    fontFamily: 'Poppins-Regular',
  },
  touch: {
    height: wp(6),
    width: wp(6),
    marginTop: wp(-3),
  },

  plusBtn: {
    width: 30,
    height: 30,
    color: '#324356',
    textAlign: 'center',
    textAlignVertical: 'center',
    borderWidth: 2,
    borderRadius: 20,
    fontSize: 18,
    fontWeight: '700',
    borderColor: '#324356',
    position: 'absolute',
    right: -16,
    top: 80,
  },

  contain: {
    // marginLeft:10,
    marginTop: hp(5),
  },
  service: {
    fontSize: fontSize.Seventeen,
    color: colors.heading,
    fontFamily: 'Poppins-Bold',
  },
  cont: {
    fontSize: fontSize.Fourteen,
    color: colors.cardcolor,
    fontFamily: 'Poppins-Regular',
    opacity: 1,
    marginTop: hp(2),
    // textAlign:'center'
  },
  shareview: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 10,
    marginTop: hp(3),
    alignItems: 'center',
    borderWidth: 0,
  },
  button1: {
    paddingVertical: wp(1.6),
    alignItems: 'center',
    backgroundColor: colors.orange,
    width: '35%',
    borderRadius: wp(1),
  },
  btext: {
    fontFamily: 'Poppins-Regular',
    fontSize: fontSize.Fourteen,
    color: colors.white,
  },
  seeall: {
    fontSize: fontSize.Fifteen,
    fontFamily: 'Poppins-Regular',
    color: colors.orange,
    marginVertical: hp(3),
    textAlign: 'right',
    marginRight: 15,
  },
  book: {
    backgroundColor: colors.orange,
    alignItems: 'center',
    justifyContent:"center",
    width: '100%',
    borderRadius: 10,
    height: wp(12),
    marginTop: hp(2),
    // borderWidth:4
  },
  btext1: {
    fontFamily: 'Poppins-Medium',
    fontSize: fontSize.Eighteen,
    color: colors.white,
  },

  courseToggle1: {
    width: '99%',
    alignSelf: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 10,
    backgroundColor: '#F6F6F6',
    marginVertical: 1,
    borderRadius: 5,

    marginBottom: 10,
  },
  activeCourseToggle: {
    marginBottom: -20,
    width: '99%',
    alignSelf: 'center',
    backgroundColor: colors.ordercolor,
  },

  activeTitleColor: {
    color: colors.orange,
    // fontSize: 14,
  },
  activeTitleColor1: {
    fontSize: 16,
    color: '#F4996C',
  },
  toggleIcon2: {
    width: 16,
    height: 16,
  },
  subItemContainer: {
    marginTop: 15,
    width: '99%',
    alignSelf: 'center',
    backgroundColor: colors.ordercolor,
    borderBottomLeftRadius: 8,
    borderBottomRightRadius: 8,
    borderColor: '#EAEAEA',
    marginBottom: 10,
  },
  singleSubItem: {
    flexDirection: 'row',
    paddingHorizontal: 15,
  },

  subItemTitle: {
    fontSize: fontSize.Sixteen,
    fontFamily: 'Poppins-Medium',
    color: colors.heading,
  },
  subItemSubtitle: {
    fontSize: fontSize.Fourteen,
    fontFamily: 'Poppins-Normal',
    color: colors.light_gr,
    marginLeft: wp(3),
    marginBottom: 15,
    // marginLeft: 16,
    // marginBottom: 15,
  },

  direction1: {
    flexDirection: 'row',
    borderWidth: 0.1,
  },

  coursetext2: {
    fontSize: fontSize.Fourteen,
    color: colors.heading,
    fontFamily: 'Poppins-SemiBold',
  },

  header1: {
    fontSize: fontSize.Eighteen,
    fontFamily: 'Poppins-Medium',
    color: colors.heading,
    marginBottom: 10,
    // textAlign: 'center',
    marginLeft: 10,
  },
  productsContainer: {
    marginBottom: 16,
    paddingVertical: 20,
   paddingHorizontal: 10,
   marginHorizontal: 5,
    backgroundColor: colors.cardm,
    borderRadius:15
  },
  productCard: {
    width: wp(38),
    minHeight: wp(45), // Fixed width for each card
    backgroundColor: colors.white,
    borderRadius: 10,
    elevation: 3,
    marginHorizontal: 18, // Add horizontal margin between cards
  },
  productImage: {
    width: '100%',
    height: wp(25),
    borderRadius: 9,
    //  resizeMode: 'contain',
    marginBottom: 8,
  },
  productName: {
    fontSize: fontSize.Fourteen,
    fontFamily: 'Poppins-Medium',
    color: colors.heading,
    marginLeft: wp(3),
    marginBottom: 4,
  },
  totalText: {
    fontSize: fontSize.Sixteen,
    fontFamily: 'Poppins-SemiBold',
    color: colors.heading,
    textAlign: 'center',
    marginVertical: 3,
  },
  button: {
    backgroundColor: '#FF8C66',
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },

  slide: {
    width: wp(44.5),
    borderRadius: 10,
    elevation: 5,
    borderRadius: 10, // Border radius scaled with wp
    backgroundColor: colors.white,
    // shadowColor: colors.black,
    // shadowOffset: { width: 0, height: wp(0.5) }, // Shadow offset with wp
    // shadowOpacity: 0.1,
    // shadowRadius: 10,
    elevation: 1,
    margin: 5,
    paddingVertical: 2,
    // padding: wp(1)
  },
  image: {
    width: '100%',
    height: wp(30),
    borderRadius: 10,
  },
  textContainer: {
    backgroundColor:colors.ordercolor,
    paddingHorizontal: 10, // Horizontal padding based on width
  },

  price: {
    fontSize: wp(4), // Price font size responsive to width
    color: 'black',
    marginBottom: hp(2), // Margin bottom based on height
  },
  buttonstylefirst: {
    backgroundColor: colors.orange,
    width: wp(30), // Width based on screen width
    paddingVertical: 7,
    borderRadius: 10,

    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },
  buttonstyle: {
    color: colors.white,
    fontSize: fontSize.Twelve,
    fontFamily: 'Poppins-Regular',
  },

  direction: {
    marginLeft: 0,
    // width: 70,
    alignSelf: 'flex-start',
    paddingBottom: 20,
  },

  third: {
    fontSize: fontSize.Fourteen,
    color: colors.cardcolor,
    fontFamily: 'Poppins-Regular',
  },
  third1: {
    fontSize: fontSize.Eighteen,
    color: colors.heading,
    fontFamily: 'Poppins-Medium',
  },
  third2: {
    fontSize: fontSize.Fourteen,
    color: '#51575C',
    fontFamily: 'Poppins-Regular',
  },
  quantitySection: {
    backgroundColor: colors.ordercolor,
    marginLeft: 20,
    // borderWidth: 1,
    borderRadius: 20,
    width: '40%',
    justifyContent: 'space-around',
    paddingHorizontal: 5,
  },
  quantityBtns: {
    fontSize: fontSize.TwentyTwo,
    color: colors.orange,
    textAlign: 'center',
    textAlignVertical: 'center',
  },
  checkboxWrapper: {
    height: 21,
    width: 21,
    position: 'absolute',
    top: 5,
    left: 5,
    justifyContent: 'center',
    alignItems: 'center',
    transform: [{scaleX: 1.2}, {scaleY: 1.2}],
    borderRadius: 4,
    borderWidth: 1,
    borderColor: '#009FDF',
    backgroundColor: '#fff',
  },
  checkedBackground: {
    backgroundColor: '#009FDF',
  },
  imageContainer: {
    margin: 5,
    width: 325, // Set the width of the images
    height: 180,
  },
  reviewCard: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    gap: 10,
    padding: 10,
  },
  reviewImage: {
    width: '100%', // Set the width of the images
    height: '100%', // Set the height of the images
    borderRadius: 10, // Optional: border radius for rounded corners
  },
  dotContainer: {
    flexDirection: 'row',
    marginVertical: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: colors.grey,
    margin: 5,
  },
  activeDot: {
    backgroundColor: colors.Headertext, // Active dot color
    width: '8%',
  },
  backBtn: {
    height: wp(4),
    width: wp(2.3),
    resizeMode: 'stretch',
    marginRight:20
  },
  bagBtn:{
    height:wp(4),
    width:wp(4),
    resizeMode:"contain"
  },
  sevicesImg:{
    width:wp(10),
    height:wp(10)
  },
  viewLine:{
    width:1,
    height:"80%",
    borderWidth:0.5,
    alignSelf:"center",
     borderColor:colors.lightGrey
  }
});
