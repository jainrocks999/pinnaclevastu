import React, {useState} from 'react';
import {
  View,
  Text,
  TextInput,
  Image,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  FlatList,
  ImageBackground,
} from 'react-native';
import styles from './styles';
import {colors} from '../../../Component/colors';
import BannerSlider from '../../../Component/Banner';
import ButtomTab from '../../../Component/ButtomTab';
import CustomRadioButton from '../../../Component/RadioButton';
import {fontSize} from '../../../Component/fontsize';
import SelectModal from '../../../Component/dropdown';
const ResidentalScreen = ({navigation}) => {
  const [selectedOption, setSelectedOption] = useState(null);
  const [visible, setVisible] = useState(false);
  const [selectedItem, setSelectedItem] = useState({
    label: '',
    value: '',
  });

  const [companyName, setCompanyName] = useState('');
  const [search, setSearch] = useState('');
  const onSelect = item => {
    setSelectedItem(item);
    setCompanyName(item.label);
    setVisible(false);
  };

  const data = [
    {label: 'male', value: 'male'},
    {label: 'Female', value: 'Female'},
    {label: 'Transgender', value: 'Transgender'},
  ];

  const options = [
    {label: 'Residential Vastu', value: 'Residential Vastu'},
    {label: 'Industrial Vastu', value: 'Industrial Vastu'},
    {label: 'Gemstone', value: 'Gemstone'},
  ];
  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Image
            style={styles.backBtn}
            source={require('../../../assets/drawer/Back1.png')}
          />
        </TouchableOpacity>

        <View style={styles.headerview}>
          <Text style={styles.logoText}>Make a Appointment</Text>
        </View>
      </View>

      <SelectModal
        search={search}
        data={data}
        setSearch={setSearch}
        visible={visible}
        onSelect={onSelect}
        onClose={value => setVisible(value)}
      />
      <ScrollView contentContainerStyle={styles.servicesContainer}>
        <View style={[styles.cardContainer2]}>
          <Text style={[styles.service, styles.widthOfSevices1]}>Services</Text>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}>
            <View>
              <CustomRadioButton
                options={options}
                selectedOption={selectedOption}
                onSelect={value => setSelectedOption(value)}
              />
            </View>
            <View style={styles.card}>
              <Text style={styles.third2}>{'₹ 5000 '}</Text>

              <Text style={styles.third2}>{'₹ 25000'}</Text>
              <Text style={[styles.third2]}>{' ₹ 500'}</Text>
            </View>
          </View>
        </View>

        <View style={styles.cardContainer2}>
          <Text style={[styles.service, {fontSize: fontSize.Fourteen}]}>
            Personal Detail
          </Text>
          <View style={styles.inputmain}>
            <Text style={styles.title2}>Full Name*</Text>
            <TextInput
              style={[styles.input,{elevation:5}]}
              placeholder="Tejash Shah"
              placeholderTextColor={colors.placeholder}
            />
          </View>
          <View style={styles.inputmain}>
            <Text style={styles.title2}>Email*</Text>
            <TextInput
              style={styles.input}
              placeholder="Email"
              placeholderTextColor={colors.placeholder}
            />
          </View>
          <View style={styles.inputmain}>
            <Text style={styles.title2}>Mobile Number*</Text>
            <TextInput
              style={styles.input}
              placeholder="Mobile Number"
              placeholderTextColor={colors.placeholder}
            />
          </View>
          <View style={styles.inputmain}>
            <Text style={styles.title2}>Gender*</Text>

            <TouchableOpacity
              onPress={() => setVisible(true)}
              style={[
                styles.input,
                {
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                },
              ]}>
              <Text
                style={{
                  color: companyName ? '#000' : colors.placeholder,
                  fontSize: fontSize.Fifteen,
                  // marginTop: 2,
                  fontFamily: 'Poppins-Regular',
                }}>
                {companyName == '' ? 'Gender' : companyName}
              </Text>
              <Image
                style={{
                  height: 8,
                  width: 15,
                }}
                source={require('../../../assets/image/arrow_icon.png')}
              />
            </TouchableOpacity>
          </View>
          <View style={styles.inputmain}>
            <Text style={styles.title2}>Current City Pincode*</Text>
            <TextInput
              style={styles.input}
              placeholder="Email"
              placeholderTextColor={colors.placeholder}
            />
          </View>

          <View style={styles.inputmain}>
            <Text style={styles.title2}>Date of Birth</Text>
            <View
              style={[
                styles.input,
                {
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                },
              ]}>
              <TextInput
                style={styles.input1}
                placeholder="Date of Birth"
                placeholderTextColor={colors.placeholder}
              />
              <Image source={require('../../../assets/image/cale.png')} />
            </View>
          </View>

          <View style={styles.inputmain}>
            <Text style={styles.title2}>Time of Birth</Text>
            <View
              style={[
                styles.input,
                {
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                },
              ]}>
              <TextInput
                style={styles.input1}
                placeholder="Time of Birth"
                placeholderTextColor={colors.placeholder}
              />
              <Image
                style={{
                  height: 20,
                  width: 20,
                }}
                source={require('../../../assets/image/Layer.png')}
              />
            </View>
          </View>

          <View style={styles.inputmain}>
            <Text style={styles.title2}>Place of Birth</Text>
            <TextInput
              style={styles.input}
              placeholder="Place of Birth"
              placeholderTextColor={colors.placeholder}
            />
          </View>
          <View style={styles.inputmain}>
            <Text style={styles.title2}>Additional Information Message</Text>
            <TextInput
              style={styles.messageInput}
              placeholder="Message ."
              placeholderTextColor={colors.placeholder}
            />
          </View>
        </View>

        <TouchableOpacity
          onPress={() => navigation.navigate('Payment', {data1: 'Residental'})}
          style={styles.book}>
          <Text style={styles.btext1}>SUBMIT</Text>
        </TouchableOpacity>
      </ScrollView>
      {/* <ButtomTab /> */}
    </View>
  );
};

export default ResidentalScreen;
