import {StyleSheet} from 'react-native';
import {fontSize} from '../../../Component/fontsize';
import {colors} from '../../../Component/colors';
import {
  widthPrecent as wp,
  heightPercent as hp,
} from '../../../Component/ResponsiveScreen/responsive';

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    // paddingTop: 50,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 15,
    paddingVertical: 10,
    backgroundColor: '#fff',
    elevation: 5,
    gap: 5,
  },
  headerview: {
   
  },
  logoText: {
    fontSize: fontSize.Eighteen,
    color: colors.heading,
    fontFamily: 'Poppins-Regular',
  },

  backBtn: {
    height: wp(4),
    width: wp(2.3),
    resizeMode: 'stretch',
    marginRight: 20,
  },
  
  title: {
    fontSize: fontSize.Fourteen,
    fontFamily: 'Poppins-Regular',
    color: colors.cardcolor,
  },
  servicesContainer: {
    paddingHorizontal: 10,
    paddingBottom:40,
    marginTop:wp(5),
    gap:30
  },

  cardContainer2: {
    // marginVertical: 20,
    width: '100%',
    paddingVertical: 10,
    // marginTop: 10,
    backgroundColor: '#fff',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#DFE7EF',
    shadowColor: '#D8E3E9',
    shadowOffset: {width: 0, height: 6},
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 10, // For Android shadow effect
    paddingHorizontal: 15,
    // margin:5,

    justifyContent: 'center',
    // marginVertical: 10,
  },
  card: {},
  third: {
    fontSize: fontSize.Fifteen,
    color: colors.orange,
    fontFamily: 'Poppins-Medium',
  },
  third1: {
    fontSize: fontSize.Eighteen,
    color: colors.heading,
    fontFamily: 'Poppins-Medium',
  },
  third2: {
    fontSize: fontSize.Thirteen,
    color: colors.cardcolor,
    fontFamily: 'Poppins-Regular',
    marginTop: hp(1),
    // textAlign:'center'
  },

  service: {
    position: 'absolute',
    top: -wp(2.8),
    left: wp(4),
    fontSize: fontSize.Fourteen,
    color: colors.heading,
    fontFamily: 'Poppins-Medium',
    backgroundColor: '#fff',
  },
  widthOfSevices1:{
    width: wp(15),
  },
  cont: {
    fontSize: fontSize.Fourteen,
    color: colors.cardcolor,
    fontFamily: 'Poppins-Regular',
    opacity: 1,
    marginTop: hp(2),
    // textAlign:'center'
  },

  inputmain: {
    marginTop: hp(1.5),
  },

  title2: {
    fontSize: fontSize.Fourteen,
    color: colors.cardcolor,
    marginLeft: wp(1),
    fontFamily: 'Poppins-Medium',
  },
  input: {
    height: wp(13),
    width: '100%',
    borderRadius: 10,
    borderWidth: 1,
    borderColor:"#E9E9E9",
    paddingHorizontal: 15,
    fontSize: fontSize.Fifteen,
    // marginTop: 2,
    fontFamily: 'Poppins-Regular',
    backgroundColor:colors.white,
   
  },
  input1: {
    height: wp(13),
    width: '60%',
    marginLeft: wp(-1),
  },

  book: {
    backgroundColor: colors.orange,
    alignItems: 'center',
    width: '100%',
    borderRadius: 10,
    paddingVertical: 15,
    marginTop: hp(1),
    // borderWidth:4
  },
  btext1: {
    fontFamily: 'Poppins-Medium',
    fontSize: fontSize.Eighteen,
    color: colors.white,
  },

  messageInput:{
    height:wp(30),
    textAlignVertical:"top",
    width: '100%',
    borderRadius: 10,
    borderWidth: 1,
    borderColor:"#E9E9E9",
    paddingHorizontal: 15,
    fontSize: fontSize.Fifteen,
    // marginTop: 2,
    fontFamily: 'Poppins-Regular',
    backgroundColor:colors.white,
  }
});
