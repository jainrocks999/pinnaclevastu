import React, {useState} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  Image,
  ScrollView,
} from 'react-native';
import styles from './styles';
import BottomNavBar from '../../../Component/ButtomTab';

const upcomingAppointments = [
  {
    id: '1',
    title: 'Residential Vastu',
    title1: 'Appointment',
    date: '25 Jan 2024',
    time: '02:30 PM',
    image: require('../../../assets/otherApp/upcoming1.png'),
  },
  {
    id: '2',
    title: 'Industrial Vastu',
    title1: 'Appointment',
    date: '25 Jan 2024',
    time: '07:00 PM',
    image: require('../../../assets/otherApp/appoinment2.png'),
  },
  {
    id: '3',
    title: 'Gemstone',
    title1: 'Appointment',
    date: '25 Jan 2024',
    time: '07:00 PM',
    image: require('../../../assets/otherApp/appoinments3.png'),
  },
];

const completedAppointments = [
  {
    id: '4',
    title: 'Shreni Rajbhandary - Vastu',
    title1: 'Appointment',
    date: '25 Jan 2024',
    time: '02:30 PM',
    reviews: '5 Reviews',
    image: require('../../../assets/otherApp/upcoming1.png'),
  },
  {
    id: '5',
    title: 'Industrial Vastu',
    title1: 'Appointment',
    date: '25 Jan 2024',
    time: '07:00 PM',
    reviews: '5 Reviews',
    image: require('../../../assets/otherApp/appoinment2.png'),
  },
  {
    id: '6',
    title: 'Gemstone',
    title1: 'Appointment',
    date: '25 Jan 2024',
    time: '07:00 PM',
    reviews: '5 Reviews',
    image: require('../../../assets/otherApp/appoinments3.png'),
  },
];

const Appointment = ({navigation}) => {
  const [selectedTab, setSelectedTab] = useState('Upcoming');
  const [appointmentsData, setAppointmentsData] =
    useState(upcomingAppointments);

  const handleTabClick = tab => {
    setSelectedTab(tab);
    if (tab === 'Upcoming') {
      setAppointmentsData(upcomingAppointments);
    } else {
      setAppointmentsData(completedAppointments);
    }
  };

  const renderAppointment = ({item}) => (
    <View style={styles.appointmentContainer}>
      <Image source={item.image} style={styles.appointmentImage} />
      <View style={styles.appointmentDetails}>
        <Text style={styles.appointmentTitle}>{item.title}</Text>
        <Text style={styles.appointmentTitle1}>{item.title1}</Text>
        <View style={styles.direction1}>
          <Image
            source={require('../../../assets/otherApp/date.png')}
            style={styles.dateimg}
          />
          <Text
            style={[
              styles.appointmentDate,
              selectedTab === 'Completed' && styles.redText,
            ]}>
            {item.date}
          </Text>
        </View>
        <View style={styles.direction1}>
          <Image
            source={require('../../../assets/otherApp/time.png')}
            style={styles.timeimg}
          />
          <Text
            style={[
              styles.appointmentTime,
              selectedTab === 'Completed' && styles.redText,
            ]}>
            {item.time}
          </Text>
        </View>
        {selectedTab === 'Completed' && (
          <View style={styles.reviewContainer}>
            <Image
              source={require('../../../assets/otherApp/review5.png')}
              style={styles.reviewIcon}
            />
            <Text style={styles.reviewText}>{item.reviews}</Text>
          </View>
        )}
      </View>
      <TouchableOpacity onPress={()=>navigation.navigate('AppoinmentDetail')} style={styles.arrowButton}>
        <Image
          source={require('../../../assets/otherApp/arrowrc.png')}
          style={styles.arrowIcon}
        />
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
       

       <View style={styles.headerview}>
       <TouchableOpacity
            onPress={() => navigation.goBack()}>
            <Image
              style={styles.backBtn}
              source={require('../../../assets/drawer/Back1.png')}
            />
          </TouchableOpacity>
         <Text style={styles.logoText}>Appointments</Text>
       </View>
     </View>
      <ScrollView contentContainerStyle={{paddingHorizontal: 20}}>
        <View style={styles.tabsContainer}>
          <TouchableOpacity
            style={[styles.tab, selectedTab === 'Upcoming' && styles.activeTab]}
            onPress={() => handleTabClick('Upcoming')}>
            <Text
              style={[
                styles.tabText,
                selectedTab === 'Upcoming' && styles.activeTabText,
              ]}>
              Upcoming
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.tab,
              selectedTab === 'Completed' && styles.activeTab,
            ]}
            onPress={() => handleTabClick('Completed')}>
            <Text
              style={[
                styles.tabText,
                selectedTab === 'Completed' && styles.activeTabText,
              ]}>
              Completed
            </Text>
          </TouchableOpacity>
        </View>

        <FlatList
          data={appointmentsData}
          renderItem={renderAppointment}
          keyExtractor={item => item.id}
        />
      </ScrollView>
      <BottomNavBar navigation={navigation}/>
    </View>
  );
};

export default Appointment;
