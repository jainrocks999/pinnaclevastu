import React, {useState} from 'react';

import {
  Text,
  View,
  TextInput,
  TouchableOpacity,
  Image,
  FlatList,
  Dimensions,
  ScrollView,
} from 'react-native';
import Collapsible from 'react-native-collapsible';
import BottomNavBar from '../../../Component/ButtomTab';
import styles from './styles';
import {colors} from '../../../Component/colors';
const {width} = Dimensions.get('window');

const dummyDatas = [
  {
    id: '1',
    title0: '01',
    title: 'Astro Vastu Classes',
    subItems: [
      {title: 'Class 01', subtitle: 'video'},
      {title: 'Class 02', subtitle: 'video'},
      {title: 'Class 03', subtitle: 'video'},
      {title: 'Class 04', subtitle: 'video'},
      {title: 'Class 05', subtitle: 'video'},
      {title: 'Class 06', subtitle: 'video'},
      {title: 'Class 07', subtitle: 'video'},
      {title: 'Class 08', subtitle: 'video'},
    ],
  },
  {
    id: '2',
    title0: '02',
    title: 'Astro - Vastu Course Material',
    subItems: [
      {title: 'Class 01', subtitle: 'video'},
      {title: 'Class 02', subtitle: 'video'},
      {title: 'Class 03', subtitle: 'video'},
      {title: 'Class 04', subtitle: 'video'},
      {title: 'Class 05', subtitle: 'video'},
      {title: 'Class 06', subtitle: 'video'},
      {title: 'Class 07', subtitle: 'video'},
      {title: 'Class 08', subtitle: 'video'},
    ],
  },
  {
    id: '3',
    title0: '03',
    title: 'Doubt Class',
    subItems: [
      {title: 'Class 01', subtitle: 'video'},
      {title: 'Class 02', subtitle: 'video'},
      {title: 'Class 03', subtitle: 'video'},
      {title: 'Class 04', subtitle: 'video'},
      {title: 'Class 05', subtitle: 'video'},
      {title: 'Class 06', subtitle: 'video'},
      {title: 'Class 07', subtitle: 'video'},
      {title: 'Class 08', subtitle: 'video'},
    ],
  },
];

const CourceListDownload = ({navigation}) => {
  const [selectedTab, setSelectedTab] = useState('Curriculum');
  const [expandedSection, setExpandedSection] = useState(null);

  const toggleSection = sectionId => {
    setExpandedSection(prevSection =>
      prevSection === sectionId ? null : sectionId,
    );
  };

  const renderSubItems = ({item}) => (
    <View style={styles.singleSubItem}>
      <View style={[styles.direction, {paddingHorizontal: 10}]}>
        <TouchableOpacity>
          <Image
            source={require('../../../assets/otherApp/vedio.png')} // Replace with your icon
            style={styles.subItemIcon}
          />
        </TouchableOpacity>
        <View>
          <Text style={styles.subItemTitle}>{item.title}</Text>
          <Text style={styles.subItemSubtitle}>{item.subtitle}</Text>
        </View>
      </View>

      <TouchableOpacity style={styles.downloadIconContainer}>
        <Image
          source={require('../../../assets/otherApp/download.png')} // Replace with your icon
          style={styles.subItemDownloadIcon}
        />
      </TouchableOpacity>
    </View>
  );

  const renderItems = ({item}) => (
    <View style={styles.paddings}>
      <TouchableOpacity
        onPress={() => toggleSection(item.id)}
        style={[
          styles.courseToggle1,
          expandedSection === item.id && styles.activeCourseToggle,
        ]}>
        <View style={styles.direction}>
          <Text
            style={[
              styles.coursetext1,
              expandedSection === item.id && styles.activeTitleColor1,
            ]}>
            {item.title0}
          </Text>
          <Text
            style={[
              styles.coursetext2,
              expandedSection === item.id && styles.activeTitleColor,
            ]}>
            {item.title}
          </Text>
        </View>
        <Image
          source={require('../../../assets/otherApp/updown2.png')} // Replace with your icon
          style={styles.toggleIcon2}
        />
      </TouchableOpacity>

      <Collapsible collapsed={expandedSection !== item.id}>
        <View style={styles.subItemContainer}>
          <FlatList
            data={item.subItems}
            keyExtractor={(subItem, index) => index.toString()}
            renderItem={renderSubItems}
          />
        </View>
      </Collapsible>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
      <TouchableOpacity
            onPress={() => navigation.goBack()}>
            <Image
              style={styles.backBtn}
              source={require('../../../assets/drawer/Back1.png')}
            />
          </TouchableOpacity>

        <View style={styles.headerview}>
          <Text style={styles.logoText}>
            {' '}
            Advance Vastu Course - 20 Nov 2024
          </Text>
        </View>
      </View>

      {/* <View style={styles.horizontalSeparator} /> */}

      {/* <View style={styles.searchContainer}>
        <Image
          source={require('../../../assets/image/search.png')}
          style={styles.searchIcon}
        />
        <TextInput
          style={styles.searchInput}
          placeholder="Search.."
          placeholderTextColor={'#D2A086'}
        />
      </View> */}
      <ScrollView
        contentContainerStyle={{
          flexGrow: 1,
          paddingBottom: '5%',
          marginTop: 15,
        }}>
        <View style={styles.searchContainer}>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Image
              style={styles.searchIcon}
              source={require('../../../assets/image/SearchIcon.png')}
            />
            <TextInput
              placeholder="Search..."
              style={styles.searchInput}
              placeholderTextColor={colors.orange}
            />
          </View>
        </View>
        <View style={styles.tabContainer}>
          {['Curriculum', 'Class Records', 'Announcements'].map(tab => (
            <TouchableOpacity
              key={tab}
              style={[
                styles.tabButton,
                selectedTab === tab && styles.activeTabButton,
              ]}
              onPress={() => setSelectedTab(tab)}>
              <Text
                style={[
                  styles.tabButtonText,
                  selectedTab === tab && styles.activeTabButtonText,
                ]}>
                {tab}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <FlatList
          data={dummyDatas}
          keyExtractor={item => item.id}
          renderItem={renderItems}
        />
      </ScrollView>
      <BottomNavBar navigation={navigation} />
    </View>
  );
};

export default CourceListDownload;
