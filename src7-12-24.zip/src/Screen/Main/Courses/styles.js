import {StyleSheet} from 'react-native';
import {
  widthPrecent as wp,
  heightPercent as hp,
} from '../../../Component/ResponsiveScreen/responsive';
import {fontSize} from '../../../Component/fontsize';
import {colors} from '../../../Component/colors';

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingHorizontal: 15,
    paddingVertical: 10,
    backgroundColor: colors.white,
    elevation: 5,
    gap: 15,
  },
  headerview: {
    flexDirection: 'row',
  },
  bagIcon: {
    position: 'absolute',
    right: 15,
  },
  logoText: {
    fontSize: fontSize.Twenty,
    fontWeight: 'bold',
    color: colors.Headertext,
    fontFamily: 'Poppins-SemiBold',
  },
  searchContainer: {
    flexDirection: 'row',
    justifyContent:"space-between",
    alignItems: 'center',
    marginHorizontal: 18,
    marginVertical: 15,
    backgroundColor: colors.ordercolor,
    borderRadius: 20,
    elevation: 3,
    paddingHorizontal: 15,
  },
  searchInput: {
    fontFamily: 'Poppins-Regular',
    width: '80%',
    fontSize: fontSize.Fourteen,
    paddingHorizontal: 15,
    color: colors.ordercolor,
    paddingVertical: 10,
  },

  filterBtn: {
    backgroundColor: colors.white,
    height: 30,
    width: 55,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 20,
  },

  scroll: {
    paddingBottom: hp(4),
  },

  switchBtnContainer: {
    margin: wp(3),
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FBF5F2',
    padding: wp(1),
    borderRadius: 10,
  },
  button: {
    flex: 1, // Each button will take equal width
    marginHorizontal: 2, // Optional, adds space between buttons
  },
  switchBtn: {
    textAlign: 'center',
    paddingVertical: wp(2),
    fontSize: fontSize.Sixteen,
    borderRadius: wp(2),
    color: colors.recorded, // Ensure colors.heading is defined elsewhere
    fontFamily: 'Poppins-Regular',
  },
  activeBtn: {
    backgroundColor: colors.orange, // Replace with colors.orange
    color: colors.white,
    elevation: 5,
    shadowColor: '#FFDECD',
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  // switchBtnContainer: {
  //   margin: wp(5),

  //   flexDirection: 'row',
  //   justifyContent: 'center',
  //   alignItems: 'center',
  //   backgroundColor: '#FBF5F2',
  //   padding: 5,
  //   borderRadius: wp(2),
  //   // gap: wp(4),
  //   opacity: 1,
  // },
  // switchBtn: {
  //    textAlign: 'center',
  //   //  textAlignVertical: 'center',
  //   padding:10,
  //  width:wp(44),
  //   fontSize: fontSize.Fourteen,
  //   borderRadius: 6,
  //   color: colors.heading,
  //   fontFamily:'Poppins-Regular'
  // },
  // activeBtn: {
  //   backgroundColor: colors.orange,
  //   shadowColor: '#FFDECD',
  //   shadowOffset: {width: 0, height: 11},
  //   shadowOpacity: 0.5,
  //   shadowRadius: 12,
  //   elevation: 12,
  //   color:colors.white,
  // },
  cardContainer: {
    // margin: 20,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: 10,
  },

  card: {
    width: wp(45),
    backgroundColor: '#FBF5F2',
    borderRadius: 10,
  },
  cardImg: {
    width: '100%',
    height: wp(40),
    resizeMode: 'contain',
    marginTop: -wp(5),
  },
  cardInfo: {
    marginTop: -30,
    padding: 10,
    gap: 6,
  },
  DateText: {
    color: colors.Headertext,
    fontSize: fontSize.Twelve,
    fontFamily: 'Poppins-Medium',
  },
  titleText: {
    fontSize: fontSize.Fourteen,
    color: colors.heading,
    fontFamily: 'Poppins-SemiBold',
  },
  regularText: {
    color: '#51575C',
    fontSize: fontSize.Fourteen,
    fontFamily: 'Poppins-Regular',
    width: '90%',
  },
  price: {
    fontSize: fontSize.Fourteen,
    color: colors.heading,
    fontFamily: 'Poppins-Bold',
  },
  cardBtn: {
    marginVertical: 5,
    color: colors.white,
    fontSize: fontSize.Twelve,
    fontFamily: 'Poppins-Medium',
    backgroundColor: colors.orange,
    padding: 10,
    width: '60%',
    textAlign: 'center',
    borderRadius: 6,
  },
});
