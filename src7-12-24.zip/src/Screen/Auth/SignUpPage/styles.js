import {Dimensions, StyleSheet} from 'react-native';
import {colors} from '../../../Component/colors/index';
import {
  heightPercent as hp,
  widthPrecent as wp,
} from '../../../Component/ResponsiveScreen/responsive';
import {fontSize} from '../../../Component/fontsize';

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  main1: {
    // paddingHorizontal: 15,
    // paddingVertical: 10,
  },
  main: {
    paddingHorizontal: 15,
    paddingVertical: 15,
    // backgroundColor: colors.white,
  },
  title: {
    fontSize: fontSize.Eighteen,
    color: colors.orange,
    fontFamily: 'Poppins-SemiBold',
  },
  subt: {
    backgroundColor: colors.ordercolor,
    paddingVertical: hp(2),
    paddingHorizontal: 15,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  inputmain: {
    marginTop: hp(2.5),
    paddingHorizontal: 15,
  },
  title1: {
    marginTop: hp(1),
    fontSize: fontSize.Nineteen,
    color: colors.cardcolor,
    fontFamily: 'Poppins-Regular',
  },
  title2: {
    fontSize: fontSize.Fourteen,
    color: colors.cardcolor,
    fontFamily: 'Poppins-Medium',
  },
  input: {
    height: wp(12),
    width: '100%',
    color: '#000',
    fontSize: fontSize.Sixteen,
    // marginTop: 2,
    fontFamily: 'Poppins-Regular',
    backgroundColor: 'white',
    borderRadius: 10,
    borderWidth: 0.5,
    paddingHorizontal: 15,
    borderColor: '#E9E9E9',
  },
  input1: {
    height:"100%",
    width: '60%',
    fontSize: fontSize.Sixteen,
    marginLeft: wp(-1),
    fontFamily: 'Poppins-Regular',
    // borderRadius: 10,
    // borderWidth: 0.5,
    paddingHorizontal:10
  },
  uppload: {
    fontSize: fontSize.Twelve,
    color: colors.please,
    marginTop: 10,
    marginLeft: wp(2),
    fontFamily: 'Poppins-Regular',
    
  },
  buttoncontainer1: {
    height: wp(10),
    width: '30%',
    backgroundColor: colors.orange,
    borderRadius: 10,
    paddingHorizontal: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttoncontainer: {
    marginHorizontal: 15,
    height: wp(12),
    // width: '90%',
    backgroundColor: colors.orange,
    borderRadius: 10,
    // opacity: 1,
    // borderWidth:1,
    marginTop: hp(2),
    marginBottom:10,
    paddingHorizontal: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },
  btext: {
    fontSize: fontSize.Eighteen,
    color: colors.white,
    fontFamily: 'Poppins-Regular',
  },
  endview: {
    marginTop: hp(2),
    justifyContent: 'center',
  },
  endtext: {
    fontSize: fontSize.Sixteen,
    fontFamily: 'Poppins-Regular',
    color: colors.white,
    textAlign: 'center',
  },
});
