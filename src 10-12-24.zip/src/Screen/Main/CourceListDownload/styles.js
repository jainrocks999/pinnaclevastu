import {StyleSheet} from 'react-native';
import {fontSize} from '../../../Component/fontsize';
import {colors} from '../../../Component/colors';
import { widthPrecent as wp } from '../../../Component/ResponsiveScreen/responsive';
export default styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    // justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 10,
    backgroundColor: '#fff',

    elevation: 2,
  },
  headerview: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logoText: {
    fontSize: fontSize.Eighteen,
    color: colors.heading,
    fontFamily: 'Poppins-Regular',
  },
  searchContainer: {
    marginHorizontal:18,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.ordercolor,
    borderRadius: wp(4),
    paddingHorizontal: 12,
    height: wp(10),
    marginBottom: 5,
  },
  searchInput: {
    flex: 1,
    color: colors.heading,
    fontFamily: 'Poppins-Regular',
    fontSize: fontSize.Fourteen,
    left: 8,
  },
  searchIcon: {
    width: wp(3),
    height: wp(3),
  },
  tabContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginHorizontal: 18,
    height: wp(13),
    marginVertical: 10,
    borderRadius: 8,
    backgroundColor: colors.ordercolor,
  },
  tabButton: {
    alignSelf: 'center',
    flex: 1,
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 0,
    borderRadius: 15,
    marginHorizontal: 4,
    backgroundColor: colors.ordercolor,
  },
  activeTabButton: {
    alignSelf: 'center',
    paddingVertical:wp(2.5),
    backgroundColor: colors.orange,
    borderRadius: 8,
    shadowColor: colors.orange, // Light pink color for the shadow
    shadowOffset: { width: 0, height: 6 }, // Offset 0px horizontally, 6px vertically
    shadowOpacity: 0.5, // Opacity of the shadow (transparent but visible)
    shadowRadius: 10, // Blur radius of 10px
    
    // Android Elevation
    elevation: 5,
  },
  tabButtonText: {
    textAlign:"center",
    textAlignVertical:"center",
    fontSize: fontSize.Fourteen,
    color: colors.recorded,
    fontFamily: 'Poppins-Regular',
  },
  activeTabButtonText: {
    color: colors.white,
  },
  horizontalSeparator: {
    width: '200%',
    height: 1,
    backgroundColor: '#EAEAEA',
  },
  courseToggle1: {
    width: '92%',
    alignSelf: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: wp(3),
    backgroundColor: '#F6F6F6',
    marginVertical: 1,
    borderRadius: 10,
    marginBottom: wp(2),
    marginHorizontal:18
  },
  activeCourseToggle: {
    marginBottom: -17,
    width: '95%',
    alignSelf: 'center',
    backgroundColor: colors.ordercolor,
    borderColor: '#EAEAEA',
    borderBottomWidth: 3,
  },
  coursetext2: {
    fontSize: fontSize.Fourteen,
    color: colors.heading,
    fontFamily: 'Poppins-Medium',
    marginLeft: 10,
  },
  coursetext1: {
    fontSize: fontSize.Fourteen,
    color: colors.Headertext,
    fontFamily: 'Poppins-Medium',
  },
  activeTitleColor: {
    color: colors.orange,
  },
  activeTitleColor1: {
    color: colors.Headertext,
  },
  toggleIcon2: {
    width: wp(3),
    height: wp(3),
    resizeMode:"contain"
  },
  subItemContainer: {
    marginTop: 15,
    width: '95%',
    alignSelf: 'center',
    backgroundColor: colors.ordercolor,
    borderBottomLeftRadius: 8,
    borderBottomRightRadius: 8,
    borderColor: '#EAEAEA',
    marginBottom: 10,
  },
  singleSubItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 10,
    //   marginLeft: 20, // Add left margin
    //   marginRight: 20, // Add right margin
    borderBottomWidth: 1, // Border after each item
    borderBottomColor: '#EAEAEA', // Border color
    marginBottom: 20, // Adds space between items
  },
  subItemIcon: {
    marginLeft: -15,
    width: wp(13),
    height: wp(10),
    marginRight: 2,
  },
  subItemTitle: {
    fontSize: fontSize.Fourteen,
    color: colors.heading,
    fontFamily: 'Poppins-Medium',
  },
  subItemSubtitle: {
    fontSize: fontSize.Eleven,
    color: colors.heading,
    fontFamily: 'Poppins-Regular',
  },
  subItemDownloadIcon: {
    width: wp(10),
    height: wp(10),
  },
  downloadIconContainer: {
    position:"absolute",
    right:5,
    // alignItems: 'center',
    // marginLeft: 5,
  },
  direction: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  backBtn: {
    height: wp(4),
    width: wp(2.3),
    resizeMode: 'stretch',
    marginRight:20
  },
});
