import {Dimensions, StyleSheet} from 'react-native';
import { colors } from '../../../Component/colors';
import { fontSize } from '../../../Component/fontsize';
import { widthPrecent as wp } from '../../../Component/ResponsiveScreen/responsive';

const {width} =Dimensions.get("screen")

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor:colors.white
  },
  header: {
    flexDirection: 'row',
    // justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 10,
    backgroundColor: '#fff',
    elevation: 2,
  },
  headerview: {
    flexDirection: 'row',
    alignItems:'center',
  },
    logoText: {
        fontSize: fontSize.Eighteen,
        color: colors.heading,
        fontFamily: 'Poppins-Regular',
      },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.ordercolor,
    borderRadius: wp(4),
    paddingHorizontal: 18,
    height:wp(10),
    marginBottom: 5,
  },
  searchInput: {
    flex: 1,
    color: colors.heading,
    fontFamily:'Poppins-Regular',
    fontSize:fontSize.Fourteen,
    left: 8,
  },
  searchIcon: {
    width: wp(3),
    height: wp(3),
  },
  headingText: {
    fontSize: fontSize.Fourteen,
    color: colors.heading,
    fontFamily:'Poppins-Medium',
  },
  cardContainer: {},
  card: {
    backgroundColor: colors.white,
    borderWidth: 1,
    flexDirection: 'row',
    justifyContent:"space-between",
    alignItems: 'center',
    padding: 10,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#D8E3E980',
    shadowColor: '#DFE7EF',
    shadowOffset: {width: 0, height: 3},
    shadowOpacity: 0.8,
    shadowRadius: 12,
    elevation: 12,
  },
  cardInfo: {
    width: '60%',
    padding: 12,
    gap: 5,
  },
  cardImg: {
    paddingVertical: 5,
    width:wp(30),
    height: '100%',
    resizeMode: 'cover',
    borderRadius:8,
    // borderWidth:1,

  },
  dateText: {
    fontSize:fontSize.Twelve,
    color: colors.heading,
    fontFamily:'Poppins-Medium',
  },
  smallText: {
    fontSize: fontSize.Ten,
    fontFamily:'Poppins-Regular',
    color: colors.heading,
  },
  progressSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  prograssbarContainer: {
    backgroundColor: '#D4EFFF',
    height: wp(0.6),
    width: '85%',
  },
  prograss:{
    flex:1,
    backgroundColor:"#52B1E9"
  },
  lightText:{
    fontSize:fontSize.Ten,
    fontFamily:'Poppins-Regular',
    color:"#CBCBCB"
  },
  backBtn: {
    height: wp(4),
    width: wp(2.3),
    resizeMode: 'stretch',
    marginRight:20
  },
});
