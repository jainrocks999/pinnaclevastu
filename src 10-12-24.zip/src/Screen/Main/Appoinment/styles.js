import {StyleSheet, Dimensions} from 'react-native';
import {fontSize} from '../../../Component/fontsize';
import {colors} from '../../../Component/colors';
import {widthPrecent as wp} from '../../../Component/ResponsiveScreen/responsive';
const {width} = Dimensions.get('window');

export default styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  header: {
    flexDirection: 'row',
    //  justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 10,
    backgroundColor: '#fff',

    elevation: 5,
  },
  headerview: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logoText: {
    fontSize: fontSize.Eighteen,
    color: colors.heading,
    fontFamily: 'Poppins-Regular',
  },
  tabsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    height: wp(13),
    marginTop: 10,
    marginBottom: 20,
    borderRadius: 10,
    backgroundColor: colors.ordercolor,
  },
  tab: {
    alignSelf: 'center',
    flex: 1,
    alignItems: 'center',
    paddingVertical: wp(2.6),
    borderRadius: 10,
    marginHorizontal: 4,
    backgroundColor: colors.ordercolor,
  },
  activeTab: {
    alignSelf: 'center',
    backgroundColor: colors.orange,
    borderRadius: 10,
    shadowColor: colors.orange, // Light pink color for the shadow
    shadowOffset: { width: 0, height: 6 }, // Offset 0px horizontally, 6px vertically
    shadowOpacity: 0.5, // Opacity of the shadow (transparent but visible)
    shadowRadius: 10, // Blur radius of 10px
    
    // Android Elevation
    elevation: 5,
  },
  tabText: {
    fontSize: fontSize.Fourteen,
    color: colors.recorded,
    fontFamily: 'Poppins-Regular',
  },
  activeTabText: {
    color: colors.white,
  },
  appointmentContainer: {
    flexDirection: 'row',
    paddingHorizontal: 10,
    paddingVertical: 10,
    alignItems: 'center',
    alignSelf: 'center',
    borderWidth: 0.5,
    borderColor:"#DFE7EF",
    gap: wp(2),
    backgroundColor: colors.white,
    borderRadius: 10,
    marginBottom: 15,
    shadowColor: '#D8E3E980', // Light pink color for the shadow
    shadowOffset: { width: 0, height: 6 }, // Offset 0px horizontally, 6px vertically
    shadowOpacity: 0.5, // Opacity of the shadow (transparent but visible)
    shadowRadius: 10, // Blur radius of 10px
    
    // Android Elevation
    elevation: 5,
  },

  appointmentImage: {
    resizeMode: 'cover',
    width: wp(30),
    height: wp(32),
    marginRight: 4,
    marginLeft: -10,
  },
  appointmentDetails: {
    paddingVertical:5,
    alignSelf:"flex-start",
    flex: 1,
    gap:3
  },
  appointmentTitle: {
    // marginTop:-3,
    // width: '130%',
    marginBottom: 3,
    fontSize: fontSize.Sixteen,
    color: colors.heading,
    fontFamily: 'Poppins-Medium',
  },
  appointmentTitle1: {
    marginBottom: 3,
    fontSize: fontSize.Twelve,
    color: colors.paymenttext,
    fontFamily: 'Poppins-Medium',
  },
  appointmentDate: {
    marginTop: 2,
    marginBottom: 5,
    fontSize: fontSize.Twelve,
    fontFamily: 'Poppins-SemiBold',
    color: colors.Headertext,
  },
  appointmentTime: {
    marginLeft: 4,
    fontSize: fontSize.Twelve,
    fontFamily: 'Poppins-SemiBold',
    color: colors.Headertext,
    // color: '#52B1E9',
  },
  redText: {
    fontSize: fontSize.Twelve,
    fontFamily: 'Poppins-SemiBold',
    color: '#F50E0E',
  },
  arrowButton: {
    padding: 5,
  },
  arrowIcon: {
    width: wp(5),
    height: wp(5),
  },
  horizontalSeparator: {
    width: '200%',
    height: 1,
    backgroundColor: '#EAEAEA',
  },
  direction1: {
    flexDirection: 'row',
  },
  dateimg: {
    width: wp(3.5),
    height: wp(4),
    resizeMode:"contain",
    marginRight:5,
  },
  timeimg: {
    width: wp(3.5),
    height: wp(4),
    resizeMode:"contain",
    marginRight:5,
  },
  reviewContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 1,
  },
  reviewText: {
    fontSize: fontSize.Twelve,
    color: colors.light_gr,
    fontFamily: 'Poppins-Regular',
    marginTop: 5,
  },
  reviewIcon: {
    width: wp(16),
    height: wp(4),
    marginTop: 5,
    marginRight: 3,
  },
  backBtn: {
    height: wp(4),
    width: wp(2.3),
    resizeMode: 'stretch',
    marginRight:20
  },
});
