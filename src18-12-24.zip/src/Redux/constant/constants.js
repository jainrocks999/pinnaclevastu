
export default BASEURLS = {
    mainUrl: 'https://vastu.craftsweb.co.in/api/v1/',
  };
  